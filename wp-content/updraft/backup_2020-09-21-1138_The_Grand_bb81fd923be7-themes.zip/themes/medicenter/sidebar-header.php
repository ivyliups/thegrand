<?php
if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('header') ):
include("searchform.php");
endif;
?>