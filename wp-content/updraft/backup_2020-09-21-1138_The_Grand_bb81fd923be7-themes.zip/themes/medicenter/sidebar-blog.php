<?php
if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('blog') ):
//here default sidebar content
endif;
?>